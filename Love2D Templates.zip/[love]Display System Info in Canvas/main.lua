-- Display LÖVE Graphics Features and System Information
-- This script gathers and displays various graphics features and system information
-- in a scrollable text format using LÖVE framework.
-- Make sure you have the FiraMono-Medium.ttf font in the same directory as this script.
-- To run it, press Ctrl+Shift+P -> Tasks: Run Task -> Run LÖVE

local infoLines = {}
local font
local scrollY = 0
local lineHeight = 20
local margin = 10
local maxScroll = 0

local function printHeader(title)
	table.insert(infoLines, string.rep(" ", 1))
    table.insert(infoLines, string.rep("=", 40))
    table.insert(infoLines, title)
    table.insert(infoLines, string.rep("=", 40))
end

local function addLine(line)
    table.insert(infoLines, line)
end

function love.load()
    -- Load bundled monospace font (FiraCode)
    font = love.graphics.newFont("FiraMono-Medium.ttf", 14)
    love.graphics.setFont(font)
    lineHeight = font:getHeight() + 2

    -- Supported features
    printHeader("Supported Graphics Features")
    local supported = love.graphics.getSupported()
    for feature, isSupported in pairs(supported) do
        addLine(string.format("  %-25s %s", feature, tostring(isSupported)))
    end

    -- Canvas formats
    printHeader("Supported Canvas Formats")
    local formats = love.graphics.getCanvasFormats()
    for format, isSupported in pairs(formats) do
        addLine(string.format("  %-10s %s", format, tostring(isSupported)))
    end

    -- Image formats
    printHeader("Supported Image Formats")
    local imageFormats = love.graphics.getImageFormats()
    for format, isSupported in pairs(imageFormats) do
        addLine(string.format("  %-10s %s", format, tostring(isSupported)))
    end

    -- Renderer info
    printHeader("Graphics Renderer Info")
    local name, version, vendor, device = love.graphics.getRendererInfo()
    addLine("  Renderer Name   : " .. name)
    addLine("  Version         : " .. version)
    addLine("  Vendor          : " .. vendor)
    addLine("  Device          : " .. device)

    -- Texture types
    printHeader("Supported Texture Types")
    local textureTypes = love.graphics.getTextureTypes()
    for textureType, isSupported in pairs(textureTypes) do
        addLine(string.format("  %-10s %s", textureType, tostring(isSupported)))
    end

    -- System limits
    printHeader("System Limits")
    local limits = love.graphics.getSystemLimits()
    for limit, value in pairs(limits) do
        addLine(string.format("  %-30s %s", limit, tostring(value)))
    end

    -- Window dimensions
    printHeader("Window Dimensions")
    local width, height = love.graphics.getDimensions()
    addLine("  Width  : " .. width)
    addLine("  Height : " .. height)

    -- Fullscreen modes
    printHeader("Supported Fullscreen Modes")
    local modes = love.window.getFullscreenModes()
    table.sort(modes, function(a, b) return a.width * a.height > b.width * b.height end)
    for i, mode in ipairs(modes) do
        addLine(string.format("  %2d: %5dx%-5d", i, mode.width, mode.height))
    end

    -- Calculate max scroll
    maxScroll = math.max(0, (#infoLines * lineHeight) - love.graphics.getHeight())
end

function love.draw()
    love.graphics.clear(0.1, 0.1, 0.1)
    love.graphics.setColor(1, 1, 1)

    love.graphics.push()
    love.graphics.translate(margin, -scrollY)

    for i, line in ipairs(infoLines) do
        love.graphics.print(line, 0, (i - 1) * lineHeight)
    end

    love.graphics.pop()
end

function love.wheelmoved(x, y)
    scrollY = scrollY - y * 40
    scrollY = math.max(0, math.min(scrollY, maxScroll))
end

function love.keypressed(key)
    if key == "up" then scrollY = scrollY - lineHeight end
    if key == "down" then scrollY = scrollY + lineHeight end
    scrollY = math.max(0, math.min(scrollY, maxScroll))
end
