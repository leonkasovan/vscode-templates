-- Load a simple shader in LÖVE (Love2D) framework
-- This example demonstrates how to load and use a shader in LÖVE.
-- It creates a simple color cycling effect based on time and screen resolution.
-- The shader is written in GLSL and is applied to the entire screen.
-- To run it, press Ctrl+Shift+P -> Tasks: Run Task -> Run LÖVE

local shader
local startTime
local shader_id

function love.load()
    love.window.setTitle("LÖVE Shader Example")
    startTime = love.timer.getTime()
    shader_id = 1
    shader = love.graphics.newShader("shader" .. shader_id .. ".glsl")
end

function love.update(dt)
    local t = love.timer.getTime() - startTime
    shader:send("iTime", t)
    shader:send("iResolution", { love.graphics.getWidth(), love.graphics.getHeight(), 0.0 })
end

function love.draw()
    love.graphics.setShader(shader)
    love.graphics.rectangle("fill", 0, 0, love.graphics.getWidth(), love.graphics.getHeight())
    love.graphics.setShader()
    love.graphics.print("FPS: " .. love.timer.getFPS(), 10, 20)
    love.graphics.print("Press Space to change shader", 10, 40)
    love.graphics.print("Current Shader ID: " .. shader_id, 10, 60)
    love.graphics.print("Press Escape to quit", 10, 80)
end

function love.keypressed(key)
	if key == "escape" then
		love.event.quit()
    elseif key == "space" then
        shader_id = (shader_id % 3) + 1
        if shader then
            shader:release()
        end        
        shader = love.graphics.newShader("shader" .. shader_id .. ".glsl")
	end
end