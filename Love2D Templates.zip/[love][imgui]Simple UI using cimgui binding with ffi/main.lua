-- This is a simple LoVE2D application using cimgui for an immediate mode GUI.
-- This example demonstrates how to create a basic ImGui window with an input field and a button.
-- It initializes cimgui, creates a window, and handles input events.

-- Build lua binding cimgui binary from source (if you want to update the binary):
--~ sudo apt install luajit
--~ git clone --recursive https://codeberg.org/apicici/cimgui-love.git
--~ cd cimgui-love/
--~ cimgui/generator/generator.sh
--~ cd cimgui/
--~ cmake .
--~ make -j8
--~ strip -s cimgui.so

local ffi = require("ffi")
local imgui = require("cimgui")

-- allocate a 256-byte buffer
local inputText = ffi.new("char[256]")

function love.load()
    imgui.love.Init()
    print("LoVE version: " .. love.getVersion())
    print("cimgui version: " .. ffi.string(imgui.GetVersion()))
end

function love.update(dt)
    imgui.love.Update(dt)
    imgui.NewFrame()
end

function love.draw()
    imgui.Begin("Demo Window")
    imgui.Text("This is an ImGui window inside LÖVE2D.")
    imgui.InputText("Input", inputText, 256)

    if imgui.Button("Click Me") then
        print("Button clicked! Text: " .. ffi.string(inputText))
    end
    imgui.End()

    imgui.Render()
    imgui.love.RenderDrawLists()
end

function love.mousemoved(x, y, ...)
    imgui.love.MouseMoved(x, y)
    if not imgui.love.GetWantCaptureMouse() then
        -- your code here
    end
end

function love.mousepressed(x, y, button, ...)
    imgui.love.MousePressed(button)
    if not imgui.love.GetWantCaptureMouse() then
        -- your code here 
    end
end

function love.mousereleased(x, y, button, ...)
    imgui.love.MouseReleased(button)
    if not imgui.love.GetWantCaptureMouse() then
        -- your code here 
    end
end

function love.textinput(t)
    imgui.love.TextInput(t)
    if imgui.love.GetWantCaptureKeyboard() then
        -- your code here 
    end
end
