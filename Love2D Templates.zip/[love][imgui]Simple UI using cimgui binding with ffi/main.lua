-- This is a simple LÖVE2D application using cimgui for an immediate mode GUI.
-- This example demonstrates how to create a basic ImGui window with an input field and a button.
-- It initializes cimgui, creates a window, and handles input events.
-- Make sure you have cimgui installed and properly set up in your LÖVE2D project.
-- https://codeberg.org/apicici/cimgui-love

local ffi = require("ffi")
local imgui = require("cimgui")

-- allocate a 256-byte buffer
local inputText = ffi.new("char[256]")

function love.load()
    imgui.love.Init()
    print("LÖVE version: " .. love.getVersion())
    print("cimgui version: " .. ffi.string(imgui.GetVersion()))
end

function love.update(dt)
    imgui.love.Update(dt)
    imgui.NewFrame()
end

function love.draw()
    imgui.Begin("Demo Window")
    imgui.Text("This is an ImGui window inside LÖVE2D.")
    imgui.InputText("Input", inputText, 256)

    if imgui.Button("Click Me") then
        print("Button clicked! Text: " .. ffi.string(inputText))
    end
    imgui.End()

    imgui.Render()
    imgui.love.RenderDrawLists()
end

function love.mousemoved(x, y, ...)
    imgui.love.MouseMoved(x, y)
    if not imgui.love.GetWantCaptureMouse() then
        -- your code here
    end
end

function love.mousepressed(x, y, button, ...)
    imgui.love.MousePressed(button)
    if not imgui.love.GetWantCaptureMouse() then
        -- your code here 
    end
end

function love.mousereleased(x, y, button, ...)
    imgui.love.MouseReleased(button)
    if not imgui.love.GetWantCaptureMouse() then
        -- your code here 
    end
end

function love.textinput(t)
    imgui.love.TextInput(t)
    if imgui.love.GetWantCaptureKeyboard() then
        -- your code here 
    end
end
