-- A simple particle effect demo using LÖVE framework
-- Make sure you have the LÖVE framework installed to run this code.
-- You can download LÖVE from https://love2d.org/
-- To run it, press Ctrl+Shift+P -> Tasks: Run Task -> Run LÖVE

local sparkImage, sparkSystem
local energyImage, energySystem
local darkImage, darkSystem
local effects = {}
local keyPressed = {}

function love.load()
    -- ==== Hit Spark Texture (elongated slash) ====
    local width, height = 32, 8
    local imgData = love.image.newImageData(width, height)
    imgData:mapPixel(function(x, y)
        local dx = (x - width / 2) / (width / 2)
        local dy = (y - height / 2) / (height / 2)
        local dist = math.sqrt(dx * dx + dy * dy)
        if dist < 1 then
            local alpha = 1 - dist
            return 1, 1, 1, alpha
        else
            return 0, 0, 0, 0
        end
    end)
    sparkImage = love.graphics.newImage(imgData)
    sparkImage:setFilter("linear", "linear")

    -- ==== Hit Spark Particle System ====
    sparkSystem = love.graphics.newParticleSystem(sparkImage, 50)
    sparkSystem:setParticleLifetime(0.1, 0.3)
    sparkSystem:setEmissionRate(0)
    sparkSystem:setSizes(1, 0.2)
    sparkSystem:setSizeVariation(1)
    sparkSystem:setSpread(math.pi * 2)
    sparkSystem:setSpeed(200, 400)
    sparkSystem:setRotation(0, 2 * math.pi)
    sparkSystem:setSpin(-10, 10)
    sparkSystem:setSpinVariation(1)
    sparkSystem:setColors(
        1, 1, 0.4, 1,
        1, 0, 0, 0
    )

    -- ==== Energy Burst Texture ====
    local glowSize = 20
    local glowData = love.image.newImageData(glowSize, glowSize)
    glowData:mapPixel(function(x, y)
        local dx = x - glowSize / 2
        local dy = y - glowSize / 2
        local dist = math.sqrt(dx * dx + dy * dy)
        local radius = glowSize / 2
        if dist < radius then
            local alpha = 1 - (dist / radius)
            return 0.2, 1.0, 0.9, alpha
        else
            return 0, 0, 0, 0
        end
    end)
    energyImage = love.graphics.newImage(glowData)
    energyImage:setFilter("linear", "linear")

    -- ==== Energy Burst Particle System ====
    energySystem = love.graphics.newParticleSystem(energyImage, 30)
    energySystem:setParticleLifetime(0.2, 0.5)
    energySystem:setEmissionRate(0)
    energySystem:setSizes(0.5, 1.2)
    energySystem:setSizeVariation(1)
    energySystem:setSpread(math.pi * 2)
    energySystem:setSpeed(100, 300)
    energySystem:setRadialAcceleration(-200, -50)
    energySystem:setSpin(-5, 5)
    energySystem:setSpinVariation(1)
    energySystem:setColors(
        0.2, 1.0, 0.9, 1,
        0.6, 0.0, 1.0, 0
    )

    -- ==== Dark Energy Swirl Texture ====
    local darkSize = 20
    local darkData = love.image.newImageData(darkSize, darkSize)
    darkData:mapPixel(function(x, y)
        local dx = x - darkSize / 2
        local dy = y - darkSize / 2
        local dist = math.sqrt(dx * dx + dy * dy)
        local radius = darkSize / 2
        if dist < radius then
            local alpha = 1 - (dist / radius)
            return 0.3, 0, 0.5, alpha -- dark purple
        else
            return 0, 0, 0, 0
        end
    end)
    darkImage = love.graphics.newImage(darkData)
    darkImage:setFilter("linear", "linear")

    -- ==== Dark Energy Particle System ====
    darkSystem = love.graphics.newParticleSystem(darkImage, 40)
    darkSystem:setParticleLifetime(0.4, 0.7)
    darkSystem:setEmissionRate(0)
    darkSystem:setSizes(1.0, 0.5)
    darkSystem:setSizeVariation(1)
    darkSystem:setSpread(math.pi * 2)
    darkSystem:setSpeed(50, 120)
    darkSystem:setRadialAcceleration(-150, -50) -- pulling inward
    darkSystem:setSpin(-10, 10)
    darkSystem:setSpinVariation(1)
    darkSystem:setColors(
        0.3, 0.0, 0.5, 0.9,
        0.1, 0.0, 0.0, 0.0
    )
	
	-- ==== Green Energy Vortex Texture ====
    local vortexSize = 30
    local vortexData = love.image.newImageData(vortexSize, vortexSize)
    vortexData:mapPixel(function(x, y)
        local dx = x - vortexSize / 2
        local dy = y - vortexSize / 2
        local dist = math.sqrt(dx * dx + dy * dy)
        local radius = vortexSize / 2
        if dist < radius then
            local alpha = 1 - (dist / radius)
            return 0.0, 1.0, 0.0, alpha -- neon green
        else
            return 0, 0, 0, 0
        end
    end)
    vortexImage = love.graphics.newImage(vortexData)
    vortexImage:setFilter("linear", "linear")

    -- ==== Green Energy Vortex Particle System ====
    vortexSystem = love.graphics.newParticleSystem(vortexImage, 40)
    vortexSystem:setParticleLifetime(0.4, 0.8)
    vortexSystem:setEmissionRate(0)
    vortexSystem:setSizes(0.5, 1.5)
    vortexSystem:setSizeVariation(1)
    vortexSystem:setSpread(math.pi * 2)
    vortexSystem:setSpeed(80, 150)
    vortexSystem:setRadialAcceleration(-300, -100)  -- inward pull for vortex
    vortexSystem:setSpin(-20, 20)  -- spin for vortex rotation
    vortexSystem:setSpinVariation(1)
    vortexSystem:setColors(
        0.0, 1.0, 0.0, 1,  -- neon green
        0.0, 0.3, 0.0, 0   -- fade out to dark green
    )
	
	-- ==== Blood Splatter Texture ====
    local bloodSize = 12
    local bloodData = love.image.newImageData(bloodSize, bloodSize)
    bloodData:mapPixel(function(x, y)
        local dx = x - bloodSize / 2
        local dy = y - bloodSize / 2
        local dist = math.sqrt(dx * dx + dy * dy)
        local radius = bloodSize / 2
        if dist < radius then
            local alpha = 1 - (dist / radius)
            return 0.6, 0, 0, alpha
        else
            return 0, 0, 0, 0
        end
    end)
    bloodImage = love.graphics.newImage(bloodData)
    bloodImage:setFilter("linear", "linear")

    -- ==== Blood Splatter Particle System ====
	bloodSystem = love.graphics.newParticleSystem(bloodImage, 100)  -- more particles
	bloodSystem:setParticleLifetime(0.5, 1.0)
	bloodSystem:setEmissionRate(0)
	bloodSystem:setSizes(1.0, 2.0)  -- bigger splats
	bloodSystem:setSizeVariation(1)
	bloodSystem:setSpread(math.pi * 2)  -- splash in all directions
	bloodSystem:setSpeed(250, 400)  -- faster spray
	bloodSystem:setLinearAcceleration(0, 300, 0, 500)  -- stronger gravity
	bloodSystem:setSpin(-4, 4)
	bloodSystem:setSpinVariation(1)
	bloodSystem:setColors(
		0.8, 0, 0, 1,   -- deep red
		0.4, 0, 0, 0    -- fade to transparent
	)

    -- Add all systems to effects table
    table.insert(effects, sparkSystem)
    table.insert(effects, energySystem)
    table.insert(effects, darkSystem)
	table.insert(effects, vortexSystem)
	table.insert(effects, bloodSystem)
end

local effectTimer = 0
local effectInterval = 0.7 -- seconds

function love.update(dt)
    for _, system in ipairs(effects) do
        system:update(dt)
    end

    effectTimer = effectTimer + dt
    if effectTimer >= effectInterval then
        effectTimer = effectTimer - effectInterval

        local x = math.random(100, 700)
        local y = math.random(100, 500)
        local effect = effects[math.random(#effects)]
        effect:setPosition(x, y)
        effect:emit(20)
    end
end


function love.draw()
    for _, system in ipairs(effects) do
        love.graphics.draw(system)
    end
end

-- Helper to detect single key press (instead of holding)
function love.keypressed(key)
    keyPressed[key] = true
end

function wasPressed(key)
    if keyPressed[key] then
        keyPressed[key] = false
        return true
    end
    return false
end
