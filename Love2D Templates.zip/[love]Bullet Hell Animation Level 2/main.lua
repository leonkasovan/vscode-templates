-- This is a simple LÖVE 2D game script that implements a bullet hell SHMUP (Shoot 'Em Up) game with a player that can shoot bullets in a spread pattern.
-- To run it, press Ctrl+Shift+P -> Tasks: Run Task -> Run LÖVE

local Player = {}
local BulletManager = {}

function love.load()
    love.window.setTitle("Bullet Hell SHMUP - Spread Pattern")
    love.window.setMode(800, 600)

    -- Player setup
    Player.x = 400
    Player.y = 550
    Player.radius = 10
    function Player:update()
        self.x, self.y = love.mouse.getPosition()
    end
    function Player:draw()
        love.graphics.setColor(0, 1, 0)
        love.graphics.circle("fill", self.x, self.y, self.radius)
    end

    -- Bullet manager setup
    BulletManager.bullets = {}
    BulletManager.speed = 400
    BulletManager.cooldown = 0.15
    BulletManager.timer = 0
    BulletManager.spreadCount = 5 -- Number of bullets per shot
    BulletManager.spreadAngle = math.rad(45) -- Total angle in radians

    function BulletManager:fireSpread(x, y)
        local half = (self.spreadCount - 1) / 2
        for i = 0, self.spreadCount - 1 do
            local angle = -math.pi / 2 + (i - half) * (self.spreadAngle / half)
            local dx = math.cos(angle)
            local dy = math.sin(angle)
            table.insert(self.bullets, {
                x = x,
                y = y,
                dx = dx,
                dy = dy
            })
        end
    end

    function BulletManager:update(dt, playerX, playerY)
        if love.mouse.isDown(1) then
            self.timer = self.timer + dt
            if self.timer >= self.cooldown then
                self:fireSpread(playerX, playerY)
                self.timer = 0
            end
        end

        for i = #self.bullets, 1, -1 do
            local b = self.bullets[i]
            b.x = b.x + b.dx * self.speed * dt
            b.y = b.y + b.dy * self.speed * dt
            if b.y < -10 or b.x < -10 or b.x > 810 then
                table.remove(self.bullets, i)
            end
        end
    end

    function BulletManager:draw()
        love.graphics.setColor(1, 0.5, 0)
        for _, b in ipairs(self.bullets) do
            love.graphics.circle("fill", b.x, b.y, 4)
        end
    end
end

function love.update(dt)
    Player:update()
    BulletManager:update(dt, Player.x, Player.y)
end

function love.draw()
    Player:draw()
    BulletManager:draw()
    love.graphics.setColor(1, 1, 1)
    love.graphics.print("Click to fire bullets in a spread pattern", 10, 10)
    love.graphics.print("Bullets per shot: " .. BulletManager.spreadCount, 10, 30)
    love.graphics.print("Spread angle: " .. math.deg(BulletManager.spreadAngle) .. " degrees", 10, 50)
    -- Draw FPS
    love.graphics.print("FPS: " .. love.timer.getFPS(), 10, 70)
end
