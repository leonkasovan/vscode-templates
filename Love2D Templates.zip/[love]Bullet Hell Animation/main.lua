-- Bullet Hell SHMUP using LÖVE 2D
-- To run it, press Ctrl+Shift+P -> Tasks: Run Task -> Run LÖVE

player = {
    x = 400,
    y = 550,
    speed = 300,
    radius = 10
}

bullets = {}
bulletSpeed = 500
bulletCooldown = 0.05
timeSinceLastShot = 0

function love.load()
    love.window.setTitle("Bullet Hell SHMUP")
    love.window.setMode(800, 600)
end

function love.update(dt)
    -- Player follows mouse
    local mx, my = love.mouse.getPosition()
    player.x = mx
    player.y = my

    -- Shooting bullets
    if love.mouse.isDown(1) then
        timeSinceLastShot = timeSinceLastShot + dt
        if timeSinceLastShot >= bulletCooldown then
            table.insert(bullets, {x = player.x, y = player.y})
            timeSinceLastShot = 0
        end
    end

    -- Update bullets
    for i = #bullets, 1, -1 do
        local b = bullets[i]
        b.y = b.y - bulletSpeed * dt
        if b.y < 0 then
            table.remove(bullets, i)
        end
    end
end

function love.draw()
    -- Draw player
    love.graphics.setColor(0, 1, 0)
    love.graphics.circle("fill", player.x, player.y, player.radius)

    -- Draw bullets
    love.graphics.setColor(1, 0.5, 0)
    for _, b in ipairs(bullets) do
        love.graphics.circle("fill", b.x, b.y, 4)
    end

    love.graphics.print("FPS: " .. love.timer.getFPS(), 10, 20)
end
