#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse
import logging
import sys

def setup_logger(verbose=False):
    logging.basicConfig(
        level=logging.DEBUG if verbose else logging.INFO,
        format="%(asctime)s - %(levelname)s - %(message)s"
    )

def cmd_hello(args):
    """Example command: prints a greeting."""
    logging.info(f"Hello, {args.name}!")

def cmd_sum(args):
    """Example command: sums numbers."""
    result = sum(args.numbers)
    logging.info(f"Sum: {result}")

def parse_args():
    parser = argparse.ArgumentParser(
        description="Example CLI Tool",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    parser.add_argument("-v", "--verbose", action="store_true", help="Enable verbose logging")

    subparsers = parser.add_subparsers(dest="command", required=True)

    # hello command
    parser_hello = subparsers.add_parser("hello", help="Print a greeting")
    parser_hello.add_argument("name", help="Name to greet")
    parser_hello.set_defaults(func=cmd_hello)

    # sum command
    parser_sum = subparsers.add_parser("sum", help="Sum a list of numbers")
    parser_sum.add_argument("numbers", type=float, nargs="+", help="Numbers to sum")
    parser_sum.set_defaults(func=cmd_sum)

    return parser.parse_args()

def main():
    args = parse_args()
    setup_logger(args.verbose)
    try:
        args.func(args)
    except Exception as e:
        logging.exception("Error occurred:")
        sys.exit(1)

if __name__ == "__main__":
    main()
