#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys
import argparse
import logging

def setup_logger():
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(levelname)s - %(message)s"
    )

def parse_args():
    parser = argparse.ArgumentParser(description="Basic Python script template.")
    parser.add_argument("-v", "--verbose", action="store_true", help="Enable verbose output")
    # Add more arguments as needed
    return parser.parse_args()

def main(args):
    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)

    logging.info("Script started.")
    # Your main logic here
    logging.info("Script finished.")

if __name__ == "__main__":
    setup_logger()
    args = parse_args()
    try:
        main(args)
    except Exception as e:
        logging.exception("An error occurred:")
        sys.exit(1)
