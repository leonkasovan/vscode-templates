--[[
Love2D lua script for loading sprite atlas
It will load atlas image in PNG format with file *.txt for atlas data.
The image and atlas data is generated using sprpack.exe -t -f output.png input_directory/ (https://gitlab.com/bztsrc/spratlas)
File atlas data has to be edited in last coloumn "Filename_GroupID_ImageNoID" => "GroupID_ImageNoID"

Dhani Novan, 10:21 10 March 2025
Jakarta
]] --

local g_players = {}
local g_loaded_atlas_img = {}
local gw, gh = love.graphics.getDimensions()
local is_playing = false
local g_player_active = 1

-- Check cache for loading atlas image
-- Memory Usage:
-- No cache (always call love.graphics.newImage): 800MB
-- Cache (call loadAtlasImage): 220MB and faster loading time
function loadAtlasImage(filename)
	for k, v in ipairs(g_loaded_atlas_img) do
		-- if found then use it
		if v.filename == filename then
			return v.image
		end
	end

	-- not found, then load it from disk
	local i = {}
	i.filename = filename
	i.image = love.graphics.newImage(filename)
	table.insert(g_loaded_atlas_img, i)
	return i.image
end

function loadChar(name, x, y)
	local player = {}
	player.name = name
	player.atlas_img = loadAtlasImage(player.name .. ".png")
	player.atlas_dat = {}
	for line in io.lines(player.name .. ".txt") do -- Iterate through each line of player.tsv (tab separated values)
		if #line > 0 then
			local src_x, src_y, src_w, src_h, dst_x, dst_y, dst_w, dst_h, spr_group_id, spr_img_no =
				line:match("(%d+)\t(%d+)\t(%d+)\t(%d+)\t(%d+)\t(%d+)\t(%d+)\t(%d+)\t(%d+)%D(%d+)")
			src_x = tonumber(src_x)
			src_y = tonumber(src_y)
			src_w = tonumber(src_w)
			src_h = tonumber(src_h)
			dst_x = tonumber(dst_x)
			dst_y = tonumber(dst_y)
			dst_w = tonumber(dst_w)
			dst_h = tonumber(dst_h)
			spr_group_id = tonumber(spr_group_id)
			spr_img_no = tonumber(spr_img_no)
			table.insert(player.atlas_dat, {src_x, src_y, src_w, src_h, dst_x, dst_y, dst_w, dst_h, spr_group_id, spr_img_no})
		end
	end
	player.atlas_img_w, player.atlas_img_h = player.atlas_img:getDimensions()
	player.x = x
	player.y = y
	player.tick = 0
	player.frame_no = 1
	return player
end

function love.load()
	love.window.setVSync(1)
	table.insert(g_players, loadChar("sprite_atlas_kfm", 50, 120))
	table.insert(g_players, loadChar("sprite_atlas_SF2_cammy", 50, 120))
	table.insert(g_players, loadChar("sprite_atlas_alice", 50, 120))
end

function love.keypressed(key)
	local player = g_players[g_player_active]

	if key == "space" then
		is_playing = not is_playing -- toggle play/pause
	elseif key == "up" then
		g_player_active = g_player_active + 1
		if g_player_active > #g_players then
            g_player_active = 1
		end
	elseif key == "down" then
		g_player_active = g_player_active - 1
		if g_player_active == 0 then
            g_player_active = #g_players
		end
	elseif key == "right" then
		player.frame_no = player.frame_no + 1
	elseif key == "left" or key == "backspace" then
		player.frame_no = player.frame_no - 1
	elseif key == "home" then
		player.frame_no = 1
	elseif key == "end" then
		player.frame_no = #player.atlas_dat
	elseif key == "pagedown" then
		player.frame_no = player.frame_no + 5
	elseif key == "pageup" then
		player.frame_no = player.frame_no - 5
    elseif key == "escape" then
        love.event.quit() -- Quit the game when ESC is pressed
	end

	-- clamp or loop index
	if player.frame_no < 1 then
		player.frame_no = 1
	elseif player.frame_no > #player.atlas_dat then
		player.frame_no = #player.atlas_dat
	end
end

function love.update(dt)
	local player = g_players[g_player_active]
	if is_playing then
		player.tick = player.tick + dt
		if player.tick > 0.15 then
			player.tick = 0
			player.frame_no = player.frame_no + 1
			if player.frame_no > #player.atlas_dat then
				player.frame_no = #player.atlas_dat
				is_playing = false
			end
		end
	end
end

function love.draw()
	local player = g_players[g_player_active]
	local data = player.atlas_dat[player.frame_no]
	if data then
		local quad = love.graphics.newQuad(data[1], data[2], data[3], data[4], player.atlas_img_w, player.atlas_img_h)
		love.graphics.draw(player.atlas_img, quad, player.x, player.y)
		love.graphics.printf(string.format("Group: %d,%d", data[9], data[10]), 0, gh / 2 + 50, gw, "center")
	else
		love.graphics.printf("Invalid frame", 0, gh / 2, gw, "center")
	end
end
