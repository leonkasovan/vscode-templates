--[[
Love2D lua script for loading sprite atlas
It will load atlas image in PNG format with file *.txt for atlas data.
The image and atlas data is generated using sprpack.exe -t -f output.png input_directory/ (https://gitlab.com/bztsrc/spratlas)
File atlas data has to be edited in last coloumn "Filename_GroupID_ImageNoID" => "GroupID_ImageNoID"

Dhani Novan, 10:21 10 March 2025
Jakarta
]] --

local max_player = 2
local players = {}
local spriteBatch
local atlas_dat = {}
local frame_no = 0
local atlas_img_w, atlas_img_h
local tick = 0
local action_id = 0
local loaded_atlas_img = {}
local gw, gh = love.graphics.getDimensions()

local current_group = nil
local current_img = nil
local frame_sequence = {}
local current_frame_index = 1
local is_playing = false
local play_timer = 0
local play_interval = 0.15 -- seconds between frames

function buildFrameSequence(player)
    frame_sequence = {}

    for group_id, group in pairs(player.atlas_dat) do
        for img_no, _ in pairs(group) do
            table.insert(frame_sequence, { group_id = group_id, img_no = img_no })
        end
    end

    -- Sort by group_id then img_no
    table.sort(frame_sequence, function(a, b)
        if a.group_id == b.group_id then
            return a.img_no < b.img_no
        else
            return a.group_id < b.group_id
        end
    end)
end


function trim(s)
	return s:match("^%s*(.-)%s*$")
end

function split(inputstr)
	local t = {}
	for str in string.gmatch(inputstr, "([^,]+)") do
		table.insert(t, trim(str))
	end
	return t
end

-- Check cache for loading atlas image
-- Memory Usage:
-- No cache (always call love.graphics.newImage): 800MB
-- Cache (call loadAtlasImage): 220MB and faster loading time
function loadAtlasImage(filename)
	for k, v in ipairs(loaded_atlas_img) do
		-- if found then use it
		if v.filename == filename then
			return v.image
		end
	end

	-- not found, then load it from disk
	i = {}
	i.filename = filename
	i.image = love.graphics.newImage(filename)
	table.insert(loaded_atlas_img, i)
	return i.image
end

function loadChar(name, x, y)
	player = {}
	player.name = name
	-- player.atlas_img = love.graphics.newImage(player.name .. ".png")
	player.atlas_img = loadAtlasImage(player.name .. ".png")
	player.atlas_dat = {}
	for line in io.lines(player.name .. ".txt") do -- Iterate through each line of player.tsv (tab separated values)
		if #line > 0 then
			src_x, src_y, src_w, src_h, dst_x, dst_y, dst_w, dst_h, spr_group_id, spr_img_no = line:match(
				"(%d+)\t(%d+)\t(%d+)\t(%d+)\t(%d+)\t(%d+)\t(%d+)\t(%d+)\t(%d+)%D(%d+)")
			src_x = tonumber(src_x)
			src_y = tonumber(src_y)
			src_w = tonumber(src_w)
			src_h = tonumber(src_h)
			dst_x = tonumber(dst_x)
			dst_y = tonumber(dst_y)
			dst_w = tonumber(dst_w)
			dst_h = tonumber(dst_h)
			spr_group_id = tonumber(spr_group_id)
			spr_img_no = tonumber(spr_img_no)

			-- Ensure atlas_dat[group_id] is a table before assigning values
			if player.atlas_dat[spr_group_id] == nil then
				player.atlas_dat[spr_group_id] = {} -- Create a new table for this key
			end
			player.atlas_dat[spr_group_id][spr_img_no] = { src_x, src_y, src_w, src_h, dst_x, dst_y, dst_w, dst_h }
		end
	end
	player.atlas_img_w, player.atlas_img_h = player.atlas_img:getDimensions()
	player.sprites = love.graphics.newSpriteBatch(player.atlas_img)
	player.state = 0
	player.x = x
	player.y = y
	player.tick = 0
	player.frame_no = 1
	return player
end

function drawSortedAtlas(player, startX, startY)
    local sorted_groups = {}
    for group_id in pairs(player.atlas_dat) do
        table.insert(sorted_groups, group_id)
    end
    table.sort(sorted_groups)

    local x, y = startX or 10, startY or 10
    for _, group_id in ipairs(sorted_groups) do
        local group = player.atlas_dat[group_id]

        local sorted_imgs = {}
        for img_no in pairs(group) do
            table.insert(sorted_imgs, img_no)
        end
        table.sort(sorted_imgs)

        for _, img_no in ipairs(sorted_imgs) do
            local frame = group[img_no]
            local quad = love.graphics.newQuad(frame[1], frame[2], frame[3], frame[4], player.atlas_img_w, player.atlas_img_h)
            love.graphics.draw(player.atlas_img, quad, x + frame[5], y + frame[6])
            love.graphics.print(string.format("%d:%d", group_id, img_no), x + frame[5], y + frame[6] - 14)
            y = y + frame[4] + 20 -- stack vertically with room for label
        end
        x = x + 100 -- shift right for next group
        y = startY or 10 -- reset Y for new group
    end
end

function love.load()
	love.window.setVSync(1)

	table.insert(players, loadChar("sprite_atlas_kfm", 50, 120))
	buildFrameSequence(players[1])
	current_group = frame_sequence[1].group_id
	current_img = frame_sequence[1].img_no
end

function love.keypressed(key)
    if key == "space" then
        is_playing = not is_playing -- toggle play/pause
    elseif key == "right" then
        current_frame_index = current_frame_index + 1
    elseif key == "left" or key == "backspace" then
        current_frame_index = current_frame_index - 1
    elseif key == "home" then
        current_frame_index = 1
    elseif key == "end" then
        current_frame_index = #frame_sequence
    elseif key == "pagedown" then
        current_frame_index = current_frame_index + 5
    elseif key == "pageup" then
        current_frame_index = current_frame_index - 5
    end

    -- clamp or loop index
    if current_frame_index < 1 then
        current_frame_index = 1
    elseif current_frame_index > #frame_sequence then
        current_frame_index = #frame_sequence
    end

    current_group = frame_sequence[current_frame_index].group_id
    current_img = frame_sequence[current_frame_index].img_no
end


function love.update(dt)
    if is_playing then
        play_timer = play_timer + dt
        if play_timer >= play_interval then
            play_timer = 0
            current_frame_index = current_frame_index + 1
            if current_frame_index > #frame_sequence then
                current_frame_index = 1
            end
            current_group = frame_sequence[current_frame_index].group_id
            current_img = frame_sequence[current_frame_index].img_no
        end
    end
end


function love.draw()
	-- Finally, draw the sprite batch to the screen.
-- 	for k, player in pairs(players) do
-- 		love.graphics.draw(player.sprites)
-- 		love.graphics.print("Action: " .. tostring(player.state), player.x, player.y + 150)
-- 		local x, y = 10, 10
-- 		for group_id, group in pairs(player.atlas_dat) do
-- 			for img_no, frame in pairs(group) do
-- 				local quad = love.graphics.newQuad(frame[1], frame[2], frame[3], frame[4], player.atlas_img_w, player.atlas_img_h)
-- 				love.graphics.draw(player.atlas_img, quad, x + frame[5], y + frame[6])
-- 				y = y + frame[6] + frame[4] + 5 -- Stack vertically
-- 			end
-- 		end
-- 	end
-- 	love.graphics.print("Current FPS: " .. tostring(love.timer.getFPS()), 20, 0)

-- 	drawSortedAtlas(players[1], 400, 20)

-- 	local stats = love.graphics.getStats()
-- 	love.graphics.print("Draw Calls: " .. stats.drawcalls, 20, 20)
-- 	love.graphics.print("Texture Memory: " .. tostring(math.floor(stats.texturememory / 1024 / 1024)) .. " MB", 20, 40)

	do
		local player = players[1]
		local frame = player.atlas_dat[current_group] and player.atlas_dat[current_group][current_img]
		if frame then
			local quad = love.graphics.newQuad(frame[1], frame[2], frame[3], frame[4], player.atlas_img_w, player.atlas_img_h)
			local cx = gw / 2 - frame[3] / 2
			local cy = gh / 2 - frame[4] / 2
			love.graphics.draw(player.atlas_img, quad, cx, cy)
			love.graphics.printf(string.format("GroupID:%d  ImageNo:%d", current_group, current_img), 0, cy + frame[4] + 10, gw, "center")
		else
			love.graphics.printf("Invalid frame", 0, gh / 2, gw, "center")
		end
	end
end
