// File: main.go
// Description: A simple Go program that greets the user by name.
// Available tasks: Ctrl+Shift+P : Run Task
// 1. Init Go Module (run once)
// 2. Build (Ctrl+Shift+B)
// 3. Run
// To enable debugging (F5), install Delve
// go install github.com/go-delve/delve/cmd/dlv@latest

package main

import (
	"fmt"
	"net/http"
)

func greetHandler(w http.ResponseWriter, r *http.Request) {
	name := r.URL.Query().Get("name")
	if name == "" {
		name = "Guest"
	}
	fmt.Fprintf(w, "Hello, %s!\n", name)
}

func main() {
	// Handle query parameters
	http.HandleFunc("/greet", greetHandler)

	// Serve static files from the "static" directory
	fs := http.FileServer(http.Dir("static"))
	http.Handle("/static/", http.StripPrefix("/static/", fs))

	// Start server
	fmt.Println("Server running at http://localhost:1234/static/")
	http.ListenAndServe(":1234", nil)
}
