// File: main.go
// Description: A simple Go program that greets the user by name.
// Available tasks: Ctrl+Shift+P : Run Task
// 1. Init Go Module (run once)
// 2. Build (Ctrl+Shift+B)
// 3. Run
// To enable debugging (F5), install Delve
// go install github.com/go-delve/delve/cmd/dlv@latest

package main

import (
	"fmt"
	"os"
)

func main() {
	if len(os.Args) < 2 {
		fmt.Println("Usage: greet <name>")
		return
	}

	name := os.Args[1]
	fmt.Printf("Hello, %s!\n", name)
}
