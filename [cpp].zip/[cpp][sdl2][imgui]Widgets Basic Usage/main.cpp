#include "imgui.h"
#include "backends/imgui_impl_sdl2.h"
#include "backends/imgui_impl_sdlrenderer2.h"
#include <SDL.h>
#include <stdbool.h>
#include <stdio.h>

#define WINDOW_WIDTH 800
#define WINDOW_HEIGHT 600

int main(int argc, char* argv[]) {
    (void) argc; (void) argv;
    
    SDL_Init(SDL_INIT_VIDEO);
    SDL_Window* window = SDL_CreateWindow("ImGui Widget Showcase",
                                          SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
                                          800, 600, SDL_WINDOW_SHOWN);
    SDL_Renderer* renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO* io = &ImGui::GetIO(); (void)io;
    ImGui::StyleColorsDark();

    ImGui_ImplSDL2_InitForSDLRenderer(window, renderer);
    ImGui_ImplSDLRenderer2_Init(renderer);

    // Widget states
    bool checkbox = false;
    int radio = 0;
    float slider = 0.5f;
    int int_slider = 5;
    float progress = 0.0f;
    int combo = 0;
    int listbox = 0;
    bool show_color = true;
    ImVec4 clear_color = ImVec4(0.2f, 0.3f, 0.4f, 1.0f);
    static char input_text[128] = "Type here";
    int counter = 0;

    bool done = false;
    while (!done) {
        SDL_Event event;
        while (SDL_PollEvent(&event)) {
            ImGui_ImplSDL2_ProcessEvent(&event);
            if (event.type == SDL_QUIT)
                done = true;
        }

        ImGui_ImplSDLRenderer2_NewFrame();
        ImGui_ImplSDL2_NewFrame();
        ImGui::NewFrame();

        ImGui::SetNextWindowPos(ImVec2(1, 1), ImGuiCond_FirstUseEver);
        ImGui::SetNextWindowSize(ImVec2(WINDOW_WIDTH-1, WINDOW_HEIGHT-1), ImGuiCond_FirstUseEver);
        ImGui::Begin("Widget Showcase");

        ImGui::Text("Basic Widgets");
        ImGui::Checkbox("Checkbox", &checkbox);
        ImGui::RadioButton("Radio 1", &radio, 0); ImGui::SameLine();
        ImGui::RadioButton("Radio 2", &radio, 1);

        ImGui::Separator();
        ImGui::Text("Sliders");
        ImGui::SliderFloat("Float Slider", &slider, 0.0f, 1.0f);
        ImGui::SliderInt("Int Slider", &int_slider, 0, 10);

        ImGui::Separator();
        ImGui::Text("Buttons");
        if (ImGui::Button("Click Me")) counter++;
        ImGui::SameLine(); ImGui::Text("Counter: %d", counter);

        ImGui::Separator();
        ImGui::Text("Text Input");
        ImGui::InputText("InputText", input_text, IM_ARRAYSIZE(input_text));

        ImGui::Separator();
        ImGui::Text("Progress");
        progress += 0.002f; if (progress > 1.0f) progress = 0.0f;
        ImGui::ProgressBar(0.5f, ImVec2(0.0f, 0.0f));

        ImGui::Separator();
        ImGui::Text("Combo & ListBox");
        const char* combo_items[] = { "Apple", "Banana", "Cherry" };
        ImGui::Combo("Combo", &combo, combo_items, IM_ARRAYSIZE(combo_items));

        const char* listbox_items[] = { "Option A", "Option B", "Option C", "Option D" };
        ImGui::ListBox("ListBox", &listbox, listbox_items, IM_ARRAYSIZE(listbox_items), 4);

        ImGui::Separator();
        ImGui::Text("Color Picker");
        if (show_color) {
            ImGui::ColorEdit3("Clear Color", (float*)&clear_color);
        }

        ImGui::Separator();
        ImGui::Text("Popup");
        if (ImGui::Button("Open Popup")) {
            ImGui::OpenPopup("MyPopup");
        }
        if (ImGui::BeginPopup("MyPopup")) {
            ImGui::Text("This is a popup!");
            if (ImGui::Button("Close")) ImGui::CloseCurrentPopup();
            ImGui::EndPopup();
        }

        ImGui::Separator();
        ImGui::Text("Tabs");
        if (ImGui::BeginTabBar("Tabs")) {
            if (ImGui::BeginTabItem("Tab A")) {
                ImGui::Text("You are in Tab A");
                ImGui::EndTabItem();
            }
            if (ImGui::BeginTabItem("Tab B")) {
                ImGui::Text("You are in Tab B");
                ImGui::EndTabItem();
            }
            ImGui::EndTabBar();
        }

        ImGui::Separator();
        if (ImGui::CollapsingHeader("Tree Example")) {
            if (ImGui::TreeNode("Parent Node")) {
                ImGui::BulletText("Leaf 1");
                ImGui::BulletText("Leaf 2");
                ImGui::TreePop();
            }
        }

        ImGui::End();

        ImGui::Render();
        SDL_SetRenderDrawColor(renderer,
                               (Uint8)(clear_color.x * 255),
                               (Uint8)(clear_color.y * 255),
                               (Uint8)(clear_color.z * 255),
                               (Uint8)(clear_color.w * 255));
        SDL_RenderClear(renderer);
        ImGui_ImplSDLRenderer2_RenderDrawData(ImGui::GetDrawData(), renderer);
        SDL_RenderPresent(renderer);
    }

    ImGui_ImplSDLRenderer2_Shutdown();
    ImGui_ImplSDL2_Shutdown();
    ImGui::DestroyContext();

    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_Quit();
    return 0;
}
