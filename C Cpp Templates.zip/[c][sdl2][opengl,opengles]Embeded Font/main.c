#include <SDL2/SDL.h>
#include "glad/glad.h"
#include "glad/glad.c"
#include "embededFont.h"

#define INIT_SCREEN_WIDTH 640
#define INIT_SCREEN_HEIGHT 480

int main(int argc, char** argv) {
	if (SDL_Init(SDL_INIT_VIDEO) != 0) {
		SDL_Log("SDL_Init failed: %s\n", SDL_GetError());
		return 1;
	}

    SDL_GL_SetAttribute(SDL_GL_CONTEXT_MAJOR_VERSION, 3);
#ifdef USE_OPENGLES
	SDL_GL_SetAttribute(SDL_GL_CONTEXT_MINOR_VERSION, 1);
	SDL_GL_SetAttribute(SDL_GL_CONTEXT_PROFILE_MASK, SDL_GL_CONTEXT_PROFILE_ES);
#else
	SDL_GL_SetAttribute(SDL_GL_CONTEXT_MINOR_VERSION, 3);
	SDL_GL_SetAttribute(SDL_GL_CONTEXT_PROFILE_MASK, SDL_GL_CONTEXT_PROFILE_CORE);
#endif    

	SDL_Window* win = SDL_CreateWindow("embededFont SDL Resize Demo",
		SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
		INIT_SCREEN_WIDTH, INIT_SCREEN_HEIGHT,
		SDL_WINDOW_OPENGL | SDL_WINDOW_SHOWN | SDL_WINDOW_RESIZABLE);

	if (!win) {
		SDL_Log("SDL_CreateWindow failed: %s\n", SDL_GetError());
		SDL_Quit();
		return 1;
	}

	SDL_GLContext ctx = SDL_GL_CreateContext(win);
	if (!ctx) {
		SDL_Log("SDL_GL_CreateContext failed: %s\n", SDL_GetError());
		SDL_DestroyWindow(win);
		SDL_Quit();
		return 1;
	}

#ifdef USE_OPENGLES
	if (!gladLoadGLES2Loader((GLADloadproc) SDL_GL_GetProcAddress)) {
#else
	if (!gladLoadGLLoader((GLADloadproc) SDL_GL_GetProcAddress)) {
#endif		
		SDL_Log("Failed to initialize GLAD\n");
		SDL_GL_DeleteContext(ctx);
		SDL_DestroyWindow(win);
		SDL_Quit();
		return 1;
	}

	int width = INIT_SCREEN_WIDTH, height = INIT_SCREEN_HEIGHT;
	glViewport(0, 0, width, height);
	glClearColor(0.1f, 0.1f, 0.1f, 1.0f);

	EmbedFontCtx* font = embedFontCreate(width, height);

	int running = 1;
	SDL_Event e;
	Uint32 lastTime = SDL_GetTicks();
	int frames = 0;
	float fps = 0.0f;
	char fpsText[64] = { 0 };

	while (running) {
		while (SDL_PollEvent(&e)) {
			if (e.type == SDL_QUIT)
				running = 0;

			if (e.type == SDL_WINDOWEVENT && e.window.event == SDL_WINDOWEVENT_RESIZED) {
				width = e.window.data1;
				height = e.window.data2;
				glViewport(0, 0, width, height);
				embedFontSetScreenSize(font, width, height);
			}
		}

		glClear(GL_COLOR_BUFFER_BIT);

		embedFontBindState(font);

		embedFontSetColor(font, 1.0f, 1.0f, 1.0f, 1.0f);
		embedFontDrawText(font, "Resize the window and text stays sharp!\nThis is embededFont.", 10.0f, 10.0f, 12.0f, 12.0f);

		embedFontSetColor(font, 0.2f, 0.8f, 1.0f, 1.0f);
		embedFontDrawText(font, "Try me at any window size!", 10.0f, 50.0f, 18.0f, 18.0f);

		embedFontSetColor(font, 1.0f, 1.0f, 0.1f, 1.0f);
		embedFontDrawText(font, "Text scales: 8x8", 10.0f, 90.0f, 8.0f, 8.0f);
		embedFontDrawText(font, "Text scales: 16x16", 10.0f, 110.0f, 16.0f, 16.0f);
		embedFontDrawText(font, "Text scales: 32x32", 10.0f, 140.0f, 32.0f, 32.0f);

		// FPS calculation
		frames++;
		Uint32 now = SDL_GetTicks();
		if (now - lastTime >= 1000) {
			fps = frames * 1000.0f / (now - lastTime);
			snprintf(fpsText, sizeof(fpsText), "FPS: %.2f", fps);
			frames = 0;
			lastTime = now;
		}
		embedFontSetColor(font, 0.0f, 1.0f, 0.0f, 1.0f);
		embedFontDrawText(font, fpsText, 10.0f, height - 26.0f, 16.0f, 16.0f);

		SDL_GL_SwapWindow(win);
	}

	embedFontDestroy(font);
	SDL_GL_DeleteContext(ctx);
	SDL_DestroyWindow(win);
	SDL_Quit();
	return 0;
}