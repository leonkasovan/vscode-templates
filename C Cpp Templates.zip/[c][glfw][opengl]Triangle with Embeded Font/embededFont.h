#ifndef EMBEDEDFONT_H
#define EMBEDEDFONT_H

/*
Embedded Font Renderer
This library provides a simple way to render text using embedded fonts in OpenGL.
It uses a texture atlas for glyphs and shaders for rendering.

Usage in main loop:
	EmbedFontCtx* font = embedFontCreate(width, height);
	embedFontBindState(font);
	embedFontSetColor(font, 1.0f, 1.0f, 0.1f, 1.0f);
	embedFontDrawText(font, "Text scales: 8x8", 10.0f, 90.0f, 8.0f, 8.0f);
	embedFontDrawText(font, "Text scales: 16x16", 10.0f, 110.0f, 16.0f, 16.0f);
	embedFontDrawText(font, "Text scales: 32x32", 10.0f, 140.0f, 32.0f, 32.0f);
	embedFontDestroy(font);
*/

#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif

typedef struct EmbedFontCtx EmbedFontCtx;

EmbedFontCtx* embedFontCreate(int screen_width, int screen_height);
void embedFontDestroy(EmbedFontCtx* ctx);

void embedFontSetScreenSize(EmbedFontCtx* ctx, int width, int height);

void embedFontBindState(EmbedFontCtx* ctx);
void embedFontSetColor(EmbedFontCtx* ctx, float r, float g, float b, float a);

// sx, sy: size in pixels for each glyph
void embedFontDrawText(EmbedFontCtx* ctx, const char* str, float x, float y, float sx, float sy);

// unsigned int embedFontGetShader(const EmbedFontCtx* ctx);
// unsigned int embedFontGetFontTexture(const EmbedFontCtx* ctx);

#ifdef __cplusplus
}
#endif

#endif // EMBEDEDFONT_H