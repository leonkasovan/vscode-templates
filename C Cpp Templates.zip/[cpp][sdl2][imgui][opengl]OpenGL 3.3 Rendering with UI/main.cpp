// main.cpp
#include <SDL.h>
#include "glad.h"
#include <stdio.h>
#include "imgui.h"
#include "imgui_impl_sdl2.h"
#include "imgui_impl_opengl3.h"

#define WINDOW_WIDTH 800
#define WINDOW_HEIGHT 600

// OpenGL shader utility
GLuint CompileShader(GLenum type, const char* src) {
    GLuint shader = glCreateShader(type);
    glShaderSource(shader, 1, &src, NULL);
    glCompileShader(shader);
    GLint ok;
    glGetShaderiv(shader, GL_COMPILE_STATUS, &ok);
    if (!ok) {
        char buf[512]; glGetShaderInfoLog(shader, 512, NULL, buf);
        printf("Shader compile error: %s\n", buf);
    }
    return shader;
}

GLuint CreateTriangleProgram() {
    const char* vs_src =
        "#version 130\n"
        "in vec2 pos;\n"
        "in vec3 color;\n"
        "out vec3 vColor;\n"
        "void main() {\n"
        "    gl_Position = vec4(pos, 0, 1);\n"
        "    vColor = color;\n"
        "}";
    const char* fs_src =
        "#version 130\n"
        "in vec3 vColor;\n"
        "out vec4 FragColor;\n"
        "void main() {\n"
        "    FragColor = vec4(vColor, 1.0);\n"
        "}";
    GLuint vs = CompileShader(GL_VERTEX_SHADER, vs_src);
    GLuint fs = CompileShader(GL_FRAGMENT_SHADER, fs_src);
    GLuint prog = glCreateProgram();
    glAttachShader(prog, vs); glAttachShader(prog, fs);
    glBindAttribLocation(prog, 0, "pos");
    glBindAttribLocation(prog, 1, "color");
    glLinkProgram(prog);
    glDeleteShader(vs); glDeleteShader(fs);
    return prog;
}

void CreateTriangleVAO(GLuint& vao, GLuint& vbo) {
    float verts[] = {
        // pos      // color
         0.0f, 0.6f, 1.0f, 0.0f, 0.0f,
         0.5f,-0.4f, 0.0f, 1.0f, 0.0f,
        -0.5f,-0.4f, 0.0f, 0.0f, 1.0f,
    };
    glGenVertexArrays(1, &vao);
    glGenBuffers(1, &vbo);
    glBindVertexArray(vao);
    glBindBuffer(GL_ARRAY_BUFFER, vbo);
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW);
    glEnableVertexAttribArray(0); // pos
    glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*) 0);
    glEnableVertexAttribArray(1); // color
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*) (2 * sizeof(float)));
    glBindVertexArray(0);
}

// Simple framebuffer and texture for offscreen rendering
void CreateFBO(GLuint& fbo, GLuint& tex, int w, int h) {
    glGenFramebuffers(1, &fbo);
    glGenTextures(1, &tex);
    glBindTexture(GL_TEXTURE_2D, tex);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, NULL);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glBindFramebuffer(GL_FRAMEBUFFER, fbo);
    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, tex, 0);
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
}

void RenderTriangleToFBO(GLuint fbo, GLuint prog, GLuint vao, int w, int h) {
    glBindFramebuffer(GL_FRAMEBUFFER, fbo);
    glViewport(0, 0, w, h);
    glClearColor(0.2f, 0.2f, 0.2f, 1);
    glClear(GL_COLOR_BUFFER_BIT);
    glUseProgram(prog);
    glBindVertexArray(vao);
    glDrawArrays(GL_TRIANGLES, 0, 3);
    glBindVertexArray(0);
    glUseProgram(0);
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
}

int main(int, char**) {
    SDL_Init(SDL_INIT_VIDEO);
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_MAJOR_VERSION, 3);
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_MINOR_VERSION, 0);
    SDL_Window* window = SDL_CreateWindow("ImGui + OpenGL Modes",
        SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, WINDOW_WIDTH, WINDOW_HEIGHT,
        SDL_WINDOW_OPENGL | SDL_WINDOW_RESIZABLE);
    SDL_GLContext gl_context = SDL_GL_CreateContext(window);
    SDL_GL_MakeCurrent(window, gl_context);
    gladLoadGLLoader((GLADloadproc) SDL_GL_GetProcAddress);
    SDL_GL_SetSwapInterval(1);

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGui_ImplSDL2_InitForOpenGL(window, gl_context);
    ImGui_ImplOpenGL3_Init("#version 130");
    ImGui::StyleColorsDark();

        // OpenGL objects
    GLuint prog = CreateTriangleProgram();
    GLuint vao = 0, vbo = 0; CreateTriangleVAO(vao, vbo);

    // FBO for triangle
    int fbw = WINDOW_WIDTH / 2, fbh = WINDOW_HEIGHT / 2;
    GLuint fbo = 0, tex = 0; CreateFBO(fbo, tex, fbw, fbh);

    int state = 1;
    bool spacePressed = false;

    bool running = true;
    bool fullscreen = false;
    SDL_Event event;
    while (running) {
        while (SDL_PollEvent(&event)) {
            ImGui_ImplSDL2_ProcessEvent(&event);
            if (event.type == SDL_QUIT)
                running = false;
            if (event.type == SDL_KEYDOWN) {
                if (event.key.keysym.sym == SDLK_SPACE && !spacePressed) {
                    state = (state % 2) + 1;
                    spacePressed = true;
                }
                if (event.key.keysym.sym == SDLK_F11) {
                    fullscreen = !fullscreen;
                    SDL_SetWindowFullscreen(window, fullscreen ? SDL_WINDOW_FULLSCREEN_DESKTOP : 0);
                }
                if (event.key.keysym.sym == SDLK_ESCAPE) {
                    running = false;
                }
            }
            if (event.type == SDL_KEYUP && event.key.keysym.sym == SDLK_SPACE) {
                spacePressed = false;
            }
        }

        ImGui_ImplOpenGL3_NewFrame();
        ImGui_ImplSDL2_NewFrame();
        ImGui::NewFrame();

        ImGui::SetNextWindowPos(ImVec2(5, 5), ImGuiCond_FirstUseEver);
        ImGui::SetNextWindowSize(ImVec2(250, 100), ImGuiCond_FirstUseEver);
        ImGui::Begin("Info");
        ImGui::Text("Current rendering in : %s", state == 1 ? "Frame" : "Window");
        ImGui::Text("Press SPACE to switch modes");
        ImGui::Text("Press F11 to toggle fullscreen");
        ImGui::Text("Press ESC to exit");
        ImGui::End();

        if (state == 2) {
            // Render to FBO, display in window and center it

            ImGui::SetNextWindowPos(ImVec2((WINDOW_WIDTH - (WINDOW_WIDTH / 2)) / 2, (WINDOW_HEIGHT - (WINDOW_HEIGHT / 2)) / 2), ImGuiCond_FirstUseEver);
            ImGui::SetNextWindowSize(ImVec2(WINDOW_WIDTH / 2, WINDOW_HEIGHT / 2), ImGuiCond_FirstUseEver);
            ImGui::Begin("Viewer");
            ImVec2 avail = ImGui::GetContentRegionAvail();
            int neww = std::max(1, (int) avail.x), newh = std::max(1, (int) avail.y);
            // Resize FBO if needed
            if (neww != fbw || newh != fbh) {
                fbw = neww; fbh = newh;
                glDeleteFramebuffers(1, &fbo); glDeleteTextures(1, &tex);
                CreateFBO(fbo, tex, fbw, fbh);
            }
            RenderTriangleToFBO(fbo, prog, vao, fbw, fbh);
            ImGui::Image((intptr_t) tex, ImVec2((float) fbw, (float) fbh), ImVec2(0, 1), ImVec2(1, 0));
            ImGui::End();
        }

        int display_w, display_h;
        SDL_GetWindowSize(window, &display_w, &display_h);
        ImGui::Render();
        glViewport(0, 0, display_w, display_h);
        glClearColor(0, 0, 0, 1);
        glClear(GL_COLOR_BUFFER_BIT);

        if (state == 1) {
            // Render triangle directly full based on window SDL_GetWindowSize without FBO
            glUseProgram(prog);
            glBindVertexArray(vao);
            glDrawArrays(GL_TRIANGLES, 0, 3);
            glBindVertexArray(0);
            glUseProgram(0);
        }

        ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
        SDL_GL_SwapWindow(window);
    }

    ImGui_ImplOpenGL3_Shutdown();
    ImGui_ImplSDL2_Shutdown();
    ImGui::DestroyContext();
    SDL_GL_DeleteContext(gl_context);
    SDL_DestroyWindow(window);
    SDL_Quit();
    return 0;
}
